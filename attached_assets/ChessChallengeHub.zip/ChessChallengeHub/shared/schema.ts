import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  score: integer("score").notNull().default(0),
  gamesPlayed: integer("games_played").notNull().default(0),
  gamesWon: integer("games_won").notNull().default(0),
  rating: integer("rating").notNull().default(1200), // Starting ELO rating
  puzzlesSolved: integer("puzzles_solved").notNull().default(0),
});

// Add practice mode to the game status options
export const gameStatusEnum = z.enum(['waiting', 'active', 'completed', 'practice']);
export type GameStatus = z.infer<typeof gameStatusEnum>;

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  player1Id: integer("player1_id").notNull().references(() => users.id),
  player2Id: integer("player2_id").references(() => users.id),
  currentPuzzle: text("current_puzzle").notNull(),
  solution: text("solution").notNull(),
  status: text("status").notNull(),
  winner: integer("winner").references(() => users.id),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  puzzleRating: integer("puzzle_rating").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  player1Id: true,
  player2Id: true,
  currentPuzzle: true,
  solution: true,
  status: true,
  puzzleRating: true,
}).extend({
  status: gameStatusEnum
});

export interface ChessPuzzle {
  id: string;
  fen: string;
  moves: string[];
  rating: number;
}

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;