import { users, type User, type InsertUser, type Game, type InsertGame, games } from "@shared/schema";
import { db } from "./db";
import { eq, or } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserScore(userId: number, won: boolean): Promise<void>;
  updateUserRating(userId: number, puzzleRating: number, solved: boolean): Promise<void>;
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: number): Promise<Game | undefined>;
  updateGameStatus(id: number, status: string): Promise<void>;
  setGameWinner(id: number, winnerId: number): Promise<void>;
  getActiveGames(): Promise<Game[]>;
  getLeaderboard(): Promise<User[]>;
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserScore(userId: number, won: boolean): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) return;

    await db
      .update(users)
      .set({
        gamesPlayed: user.gamesPlayed + 1,
        gamesWon: won ? user.gamesWon + 1 : user.gamesWon,
        score: won ? user.score + 10 : user.score,
      })
      .where(eq(users.id, userId));
  }

  async updateUserRating(userId: number, puzzleRating: number, solved: boolean): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) return;

    const expectedScore = 1 / (1 + Math.pow(10, (puzzleRating - user.rating) / 400));
    const actualScore = solved ? 1 : 0;
    const newRating = Math.round(user.rating + 32 * (actualScore - expectedScore));

    await db
      .update(users)
      .set({
        rating: newRating,
        puzzlesSolved: solved ? user.puzzlesSolved + 1 : user.puzzlesSolved,
        score: solved ? user.score + Math.round(puzzleRating / 100) : user.score,
      })
      .where(eq(users.id, userId));
  }

  async createGame(game: InsertGame): Promise<Game> {
    const [newGame] = await db.insert(games).values(game).returning();
    return newGame;
  }

  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game;
  }

  async updateGameStatus(id: number, status: string): Promise<void> {
    await db.update(games).set({ status }).where(eq(games.id, id));
  }

  async setGameWinner(id: number, winnerId: number): Promise<void> {
    await db
      .update(games)
      .set({ winner: winnerId, status: 'completed' })
      .where(eq(games.id, id));

    const game = await this.getGame(id);
    if (game) {
      await this.updateUserRating(winnerId, game.puzzleRating, true);
    }
  }

  async getActiveGames(): Promise<Game[]> {
    return db
      .select()
      .from(games)
      .where(
        or(
          eq(games.status, 'active'),
          eq(games.status, 'waiting')
        )
      );
  }

  async getLeaderboard(): Promise<User[]> {
    return db.select().from(users).orderBy(users.rating, { desc: true }).limit(10);
  }
}

export const storage = new DatabaseStorage();