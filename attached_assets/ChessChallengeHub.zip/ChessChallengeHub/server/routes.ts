import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertGameSchema } from "@shared/schema";
import { getPuzzleForRating } from "./puzzles";

interface WebSocketMessage {
  type: 'join_game' | 'game_move' | 'chat_message' | 'game_update';
  payload: any;
}

interface AuthenticatedWebSocket extends WebSocket {
  userId?: number;
  gameId?: number;
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Get active games
  app.get("/api/games", async (_req, res) => {
    const games = await storage.getActiveGames();
    res.json(games);
  });

  // Create new game
  app.post("/api/games", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const puzzle = getPuzzleForRating(req.user.rating);
    const gameData = {
      player1Id: req.user.id,
      currentPuzzle: puzzle.fen,
      solution: puzzle.moves[0],
      status: 'waiting',
      puzzleRating: puzzle.rating
    };

    const parseResult = insertGameSchema.safeParse(gameData);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    const game = await storage.createGame(parseResult.data);
    res.status(201).json(game);
  });

  // Create practice game
  app.post("/api/games/practice", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const puzzle = getPuzzleForRating(req.user.rating);
    const gameData = {
      player1Id: req.user.id,
      currentPuzzle: puzzle.fen,
      solution: puzzle.moves[0],
      status: 'practice',
      puzzleRating: puzzle.rating
    };

    const parseResult = insertGameSchema.safeParse(gameData);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    const game = await storage.createGame(parseResult.data);
    res.status(201).json(game);
  });

  // Get specific game
  app.get("/api/games/:id", async (req, res) => {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game) return res.sendStatus(404);
    res.json(game);
  });

  // Join game
  app.post("/api/games/:id/join", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game || game.status !== 'waiting') {
      return res.sendStatus(400);
    }

    await storage.updateGameStatus(gameId, 'active');
    res.sendStatus(200);
  });

  // Update game status
  app.post("/api/games/:id/status", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }

    const { status } = req.body;
    await storage.updateGameStatus(gameId, status);
    res.sendStatus(200);
  });

  // Set game winner
  app.post("/api/games/:id/winner", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }

    const { winnerId } = req.body;
    await storage.setGameWinner(gameId, winnerId);
    await storage.updateUserScore(winnerId, true);
    res.sendStatus(200);
  });

  // Add cancel game endpoint
  app.post("/api/games/:id/cancel", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ error: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game) return res.sendStatus(404);

    // Only allow canceling if the user is the game creator
    if (game.player1Id !== req.user.id) {
      return res.sendStatus(403);
    }

    await storage.updateGameStatus(gameId, 'completed');
    res.sendStatus(200);
  });

  // Get leaderboard
  app.get("/api/leaderboard", async (_req, res) => {
    const leaders = await storage.getLeaderboard();
    res.json(leaders);
  });

  const httpServer = createServer(app);

  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Map<AuthenticatedWebSocket, { userId: number, gameId?: number }>();

  wss.on('connection', (ws: AuthenticatedWebSocket) => {
    ws.on('message', async (data: string) => {
      try {
        const message: WebSocketMessage = JSON.parse(data);

        switch (message.type) {
          case 'join_game':
            const clientInfo = {
              userId: message.payload.userId,
              gameId: message.payload.gameId
            };
            clients.set(ws, clientInfo);
            ws.userId = clientInfo.userId;
            ws.gameId = clientInfo.gameId;
            break;

          case 'chat_message':
            if (!ws.userId || !ws.gameId) break;

            // Broadcast chat message to all clients in the same game
            clients.forEach((info, client) => {
              if (info.gameId === ws.gameId && client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'chat_message',
                  payload: {
                    userId: ws.userId,
                    message: message.payload.message,
                    timestamp: new Date().toISOString()
                  }
                }));
              }
            });
            break;

          case 'game_move':
            if (!ws.userId || !ws.gameId) break;

            // Handle game moves and broadcast updates
            clients.forEach((info, client) => {
              if (info.gameId === ws.gameId && client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'game_update',
                  payload: message.payload
                }));
              }
            });
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
    });
  });

  return httpServer;
}