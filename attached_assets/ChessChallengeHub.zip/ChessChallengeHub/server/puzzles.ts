import { ChessPuzzle } from "@shared/schema";

const puzzleData: ChessPuzzle[] = [
  {
    id: "puzzle1",
    fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3",
    moves: ["Bc5", "Bxf7+", "Kxf7", "Nxe5+"],
    rating: 1200,
  },
  {
    id: "puzzle2",
    fen: "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4",
    moves: ["Ng5", "d5", "exd5", "Na5"],
    rating: 1400,
  },
  {
    id: "puzzle3",
    fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2",
    moves: ["d5", "exd5", "Qxd5", "Nc3"],
    rating: 1100,
  },
  // Adding more puzzles with varying difficulties
  {
    id: "puzzle4",
    fen: "2r3k1/pp2qpp1/2n1p2p/2n5/2P5/P2P2P1/B4P1P/2R1R1K1 w - - 0 1",
    moves: ["Rxc5", "Rxc5", "Rxe6", "Qxe6"],
    rating: 1600,
  },
  {
    id: "puzzle5",
    fen: "r4rk1/ppp2ppp/2n5/2bqp3/8/P2PB3/1PP2PPP/R2Q1RK1 w - - 0 1",
    moves: ["Bb6", "Qxb3", "Bxc5", "Qxa3"],
    rating: 1800,
  }
];

// Get a puzzle appropriate for the player's skill level
export function getPuzzleForRating(playerRating: number): ChessPuzzle {
  // Find puzzles within 200 rating points of the player's rating
  const appropriatePuzzles = puzzleData.filter(puzzle => 
    Math.abs(puzzle.rating - playerRating) <= 200
  );

  if (appropriatePuzzles.length === 0) {
    // If no appropriate puzzles found, get the closest one
    return puzzleData.reduce((closest, current) => 
      Math.abs(current.rating - playerRating) < Math.abs(closest.rating - playerRating)
        ? current
        : closest
    );
  }

  // Randomly select one of the appropriate puzzles
  const randomIndex = Math.floor(Math.random() * appropriatePuzzles.length);
  return appropriatePuzzles[randomIndex];
}

export function getRandomPuzzle(): ChessPuzzle {
  const randomIndex = Math.floor(Math.random() * puzzleData.length);
  return puzzleData[randomIndex];
}

export function validateMove(puzzle: ChessPuzzle, move: string, moveIndex: number): boolean {
  return puzzle.moves[moveIndex] === move;
}

export function calculateDifficultyLabel(rating: number): string {
  if (rating < 1200) return "Beginner";
  if (rating < 1400) return "Intermediate";
  if (rating < 1600) return "Advanced";
  if (rating < 1800) return "Expert";
  return "Master";
}

export const puzzles = new Map(
  puzzleData.map(puzzle => [puzzle.id, puzzle])
);