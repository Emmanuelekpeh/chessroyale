import { useEffect, useRef, useCallback } from 'react';
import { useToast } from './use-toast';

interface WebSocketMessage {
  type: 'join_game' | 'game_move' | 'chat_message' | 'game_update';
  payload: any;
}

export function useWebSocket(gameId?: number, userId?: number) {
  const ws = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      if (gameId && userId) {
        ws.current?.send(JSON.stringify({
          type: 'join_game',
          payload: { gameId, userId }
        }));
      }
    };

    ws.current.onclose = () => {
      toast({
        title: "Connection lost",
        description: "Trying to reconnect...",
        variant: "destructive",
      });
    };

    return () => {
      ws.current?.close();
    };
  }, [gameId, userId]);

  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify(message));
    }
  }, []);

  const subscribeToMessages = useCallback((callback: (message: WebSocketMessage) => void) => {
    if (!ws.current) return;

    ws.current.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        callback(message);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };
  }, []);

  return {
    sendMessage,
    subscribeToMessages,
    isConnected: ws.current?.readyState === WebSocket.OPEN,
  };
}
