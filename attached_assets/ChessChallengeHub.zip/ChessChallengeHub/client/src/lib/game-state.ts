import type { GameState } from "@shared/schema";

export function isGameActive(game: GameState): boolean {
  return game.status === "active";
}

export function isPlayerTurn(game: GameState, playerId: number): boolean {
  return game.currentTurn === playerId;
}

export function getWinner(game: GameState): number | null {
  if (game.status !== "complete") return null;
  if (game.player1Score > game.player2Score) return game.player1;
  if (game.player2Score > game.player2Score) return game.player2;
  return null;
}
